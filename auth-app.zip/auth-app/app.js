const express = require('express');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const authRoutes = require('./routes/auth');
const app = express();
const port = 3000;

app.use(cookieParser());
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// This is the middleware to handle form data
app.use(express.urlencoded({ extended: false }));
app.use('/', authRoutes);

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});