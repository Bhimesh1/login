This is a simple authentication app built with Node.js, Express,. It enables users to sign up for an account and log in, and store personal information, like their full name, after they log in.


To start with running the code-
Open your terminal or command prompt in the `auth-app` directory.
Install Dependencies: npm install

And then to run the application you will have to enter command: node app.js

And then go to the browser and search: localhost:3000/home

Then you will be redirected to the login page and you can sign up.



App workings-
1. Sign Up: You can create an account with your emailid and password and they’re redirected to the login page.

2. Login: You can now log in with your credentials. If its valid then a JWT token is created and stored as a cookie. Successful login will redirect you to the home page.

3. Home Page: This page is protected and only available for logged-in users only. It shows the user's email and them you can submit your full name, which gets stored and displayed.

Logout: When you click logout then it clears the cookie and redirects you back to the login page.



Files Explanation-
app.js
-This is the main server file that will set up the Express server.

routes/auth.js
-This file contains the main routes for user authentication:
GET /signup: It renders the signup page.
POST /signup: It handles user registration by hashing the password and storing user data.
GET /login: It will render the login page.
POST /login: It will authenticate the user and will generate a JWT token.



