const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const bodyParser = require('body-parser');
const router = express.Router();
const cookieParser = require('cookie-parser');
const JWT_SECRET = 'jwt_secret_key';

// Its the middleware to parse the form data
router.use(bodyParser.urlencoded({ extended: true }));
router.use(cookieParser());

const users = {};

// signup
router.get('/signup', (req, res) => {
  res.render('signup');
});

// This is the handeling signup form submission
router.post('/signup', (req, res) => {
  console.log(req.body);

  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).send('Email and password are required.');
  }

  if (users[email]) {
    return res.status(400).send('User already exists.');
  }

  // Hashing the password
  bcrypt.hash(password, 10, (err, hashedPassword) => {
    if (err) {
      return res.status(500).send('Error hashing password.');
    }

    // Storing user data
    users[email] = {
      password: hashedPassword,
      fullName: null,
    };

    res.redirect('/login');
  });
});

router.get('/login', (req, res) => {
  res.render('login');
});

// Handle login form submission
router.post('/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).send('Email and password are required.');
  }

  const user = users[email];

  if (!user) {
    return res.status(400).send('Invalid credentials.');
  }

  // Here it compares the  hashed password
  bcrypt.compare(password, user.password, (err, isMatch) => {
    if (err) {
      return res.status(500).send('Error during password comparison.');
    }
    if (!isMatch) {
      return res.status(400).send('Invalid credentials.');
    }

    const token = jwt.sign({ email: email }, JWT_SECRET, {
      expiresIn: '1h',
    });

    res.cookie('token', token, {
      httpOnly: true,
      secure: false,
      maxAge: 3600000,
    });

    res.redirect('/home');
  });
});

// This is the middleware to protect routes
function authenticateToken(req, res, next) {
  const token = req.cookies.token;
  if (!token) {
    return res.redirect('/login');
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.redirect('/login');
    }
    req.user = user;
    next();
  });
}

router.get('/home', authenticateToken, (req, res) => {
  const user = users[req.user.email];

  res.render('home', { email: req.user.email, fullName: user.fullName });
});

// Handling the form submission (Post user's full name)
router.post('/submit-name', authenticateToken, (req, res) => {
  const fullName = req.body.fullname;
  const user = users[req.user.email];

  user.fullName = fullName;

  res.render('home', { email: req.user.email, fullName });
});

// Logout
router.get('/logout', (req, res) => {
  res.clearCookie('token');
  res.redirect('/login');
});

module.exports = router;
